<?php
return array(
	'theme_name' => 'Striking MultiFlex', 
	'theme_slug' => 'strikingr',
	'theme_version' => '1.2.1.1',
	'required_wp_version' => '4.2',
);