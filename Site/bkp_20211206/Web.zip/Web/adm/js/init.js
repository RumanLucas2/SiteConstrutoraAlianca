jQuery(document).ready(function($)
{
	$(document).pngFix();
});